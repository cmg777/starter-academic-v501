# r_demeaning_twfe — Quarto project

Executable companion to the blog post:

> **What Does TWFE Actually Do? Manual Demeaning and the FWL Theorem**
> <https://carlos-mendez.org/post/r_demeaning_twfe/>

## Contents

| File | Purpose |
|------|---------|
| `tutorial.qmd` | Self-contained Quarto notebook — prose, code, output, and figures inline. The didactic, render-and-read version of the tutorial. |
| `analysis.R` | Canonical companion script — equivalent logic, runnable directly with `Rscript analysis.R`. Useful if you prefer plain-R execution over rendering. |
| `_quarto.yml` | Minimal Quarto project marker so Positron / RStudio open this folder as a recognised Quarto project (no prompt for a project directory). |
| `README.md` | This file. |

## How to render the tutorial

1. Open this folder in **Positron** or **RStudio**.
2. Open `tutorial.qmd` and click **Render** (or run
   `quarto render tutorial.qmd` from a terminal in this folder).
3. The `setup-packages` chunk pins **exact versions** of every
   top-level R package via `pak::pkg_install("pkg@x.y.z")` and
   installs them on first run (subsequent renders reuse the
   cached versions).
4. The rendered output is `tutorial.html` plus a `tutorial_files/`
   directory of figures. Both are regenerated each time you render.

## How to run the canonical script directly

```bash
Rscript analysis.R 2>&1 | tee execution_log.txt
```

The script downloads the Barro-style cross-country convergence panel
(150 countries × 8 time periods) from the GitHub raw URL of the
published post (with a local-file fallback if you place the dataset
next to the script).

## Requirements

- **Quarto** ≥ 1.4
- **R** ≥ 4.5
- ~150 MB of CRAN packages on first install (cached after that)

## References

- **Published post:** <https://carlos-mendez.org/post/r_demeaning_twfe/>
- **Source repo:** <https://github.com/cmg777/starter-academic-v501>
- **Methodology:** Frisch, R. & Waugh, F. V. (1933). Partial Time Regressions as Compared with Individual Trends. *Econometrica*, 1(4), 387–401.
- **Data source:** Simulated panel inspired by Barro & Sala-i-Martin (2004). *Economic Growth* (2nd ed.). MIT Press.
