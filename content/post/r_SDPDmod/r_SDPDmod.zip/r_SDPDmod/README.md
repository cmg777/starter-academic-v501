# r_SDPDmod — Quarto project

Executable companion to the blog post:

> **Spatial Dynamic Panel Data Modeling in R: Cigarette Demand Across US States**
> <https://carlos-mendez.org/post/r_SDPDmod/>

## Contents

| File | Purpose |
|------|---------|
| `tutorial.qmd` | Self-contained Quarto notebook — prose, code, output, and figures inline. The didactic, render-and-read version of the tutorial. |
| `analysis.R` | Canonical companion script — equivalent logic, runnable directly with `Rscript analysis.R`. Useful if you prefer plain-R execution over rendering. |
| `_quarto.yml` | Minimal Quarto project marker so Positron / RStudio open this folder as a recognised Quarto project (no prompt for a project directory). |
| `README.md` | This file. |

## How to render the tutorial

1. Open this folder in **Positron** or **RStudio**.
2. Open `tutorial.qmd` and click **Render** (or run
   `quarto render tutorial.qmd` from a terminal in this folder).
3. The `setup-packages` chunk pins **exact versions** of every
   top-level R package via `pak::pkg_install("pkg@x.y.z")` and
   installs them on first run (subsequent renders reuse the
   cached versions).
4. The rendered output is `tutorial.html` plus a `tutorial_files/`
   directory of figures. Both are regenerated each time you render.

## How to run the canonical script directly

```bash
Rscript analysis.R 2>&1 | tee execution_log.txt
```

The script uses the `Cigar` panel (46 US states, 1963–1992) bundled with
the `plm` R package — no external download required.

## Requirements

- **Quarto** ≥ 1.4
- **R** ≥ 4.5
- ~150 MB of CRAN packages on first install (cached after that)

## References

- **Published post:** <https://carlos-mendez.org/post/r_SDPDmod/>
- **Source repo:** <https://github.com/cmg777/starter-academic-v501>
- **Methodology:** Lee, L.-F. & Yu, J. (2010). Estimation of Spatial Autoregressive Panel Data Models with Fixed Effects. *Journal of Econometrics*, 154(2), 165–185.
- **Data source:** Baltagi, B. H. & Levin, D. (1992). Cigarette Taxation: Raising Revenues and Reducing Consumption. *Structural Change and Economic Dynamics*, 3(2), 321–335.
