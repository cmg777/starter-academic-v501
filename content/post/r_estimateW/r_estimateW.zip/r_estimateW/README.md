# r_estimateW — Quarto project

Companion bundle for the tutorial **"Who Are My Neighbors? Bayesian Estimation of
Spatial Weight Matrices in R"**.

Published post: <https://carlos-mendez.org/post/r_estimatew/>

## Contents

| File | What it is |
|---|---|
| `tutorial.qmd` | The rendered walkthrough. Downloads the cached MCMC fits from the post's repository, so it knits in about a minute instead of forty. |
| `analysis.R` | The canonical script. Runs the full analysis from scratch: 19 figures, 15 CSV tables, all three 90-region chains, the ground-truth simulation and the taxonomy tour. |
| `_quarto.yml` | Minimal Quarto project file. |
| `README.md` | This file. |

## How to render the tutorial

Open `tutorial.qmd` in Positron or RStudio and press **Render**, or from a terminal:

```bash
quarto render tutorial.qmd
```

The first render downloads about 220 KB of cached `.rds` and `.csv` files into a
local `cache/` folder. After that it works offline.

## How to run the canonical script

```bash
Rscript analysis.R 2>&1 | tee execution_log.txt
```

Cold, this takes roughly 40 minutes — almost all of it in the three 90-region
Gibbs chains, which sample 8,010 candidate links per sweep. Results are memoised
into `cache/` under keys encoding seed, n, T, niter, nretain and kbar, so re-runs
take about a minute. Set `ESTIMATEW_REFIT=TRUE` to force a genuine recompute, or
`ESTIMATEW_BUDGET_SEC` to change how long the robustness chains may run.

## Requirements

- Quarto >= 1.4
- R >= 4.4 (developed on 4.5.2)
- CRAN packages: `estimateW` (0.2.0), `sf`, `coda`, `circlize`, `ggplot2`,
  `dplyr`, `tidyr`, `readr`, `tibble`, `purrr`, `glue`, `scales`, `patchwork`.
  The script installs anything missing. `sf` needs GDAL/GEOS/PROJ.

Reproducing the paper's Table 3 exactly requires `estimateW` 0.2.0, seed 571 and
the Mersenne-Twister RNG. A different BLAS may change the last decimals; the
audit table reports differences in Monte Carlo standard-error units so you can
tell noise from a real discrepancy.

## References

- Krisztin, T. & Piribauer, P. (2026). *estimateW: a Bayesian R package for
  estimating spatial weight matrices, with an application to European regional
  growth*. Springer, open access.
- Krisztin, T. & Piribauer, P. (2023). A Bayesian approach for the estimation of
  weight matrices in spatial autoregressive models. *Spatial Economic Analysis*
  18(1), 44–63.
- Package: <https://CRAN.R-project.org/package=estimateW>
- Data: Eurostat regional accounts, shipped with the package as `nuts1growth`.
