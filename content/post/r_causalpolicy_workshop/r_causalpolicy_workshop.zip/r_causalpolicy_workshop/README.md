# r_causalpolicy_workshop — Quarto project

Executable companion to the blog post:

> **Six Ways to Evaluate a Policy using R: Comparative Case Studies of Proposition 99**
> <https://carlos-mendez.org/post/r_causalpolicy_workshop/>

## Contents

| File | Purpose |
|------|---------|
| `tutorial.qmd` | Self-contained Quarto notebook — prose, code, output, and figures inline. The didactic, render-and-read version of the tutorial. |
| `analysis.R` | Canonical companion script — equivalent logic, runnable directly with `Rscript analysis.R`. Useful if you prefer plain-R execution over rendering. |
| `_quarto.yml` | Minimal Quarto project marker so Positron / RStudio open this folder as a recognised Quarto project (no prompt for a project directory). |
| `README.md` | This file. |

## How to render the tutorial

1. Open this folder in **Positron** or **RStudio**.
2. Open `tutorial.qmd` and click **Render** (or run
   `quarto render tutorial.qmd` from a terminal in this folder).
3. The `setup-packages` chunk pins **exact versions** of every
   top-level R package via `pak::pkg_install("pkg@x.y.z")` and
   installs them on first run (subsequent renders reuse the
   cached versions).
4. The rendered output is `tutorial.html` plus a `tutorial_files/`
   directory of figures. Both are regenerated each time you render.

## How to run the canonical script directly

```bash
Rscript analysis.R 2>&1 | tee execution_log.txt
```

The script downloads the Proposition 99 cigarette panel (39 US states, 1970–2000)
from the GitHub raw URL of the published post (with a local-file fallback if you
place the dataset next to the script).

## Requirements

- **Quarto** ≥ 1.4
- **R** ≥ 4.5
- ~150 MB of CRAN packages on first install (cached after that)

## References

- **Published post:** <https://carlos-mendez.org/post/r_causalpolicy_workshop/>
- **Source repo:** <https://github.com/cmg777/starter-academic-v501>
- **Methodology:** Abadie, Diamond & Hainmueller (2010). Synthetic Control Methods for Comparative Case Studies. *JASA*, 105(490), 493–505.
- **Data source:** California's Proposition 99 cigarette panel, as documented in Abadie, Diamond & Hainmueller (2010).
