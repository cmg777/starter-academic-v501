# r_did — Quarto project

Executable companion to the blog post:

> **Difference-in-Differences for Policy Evaluation: A Tutorial using R**
> <https://carlos-mendez.org/post/r_did/>

## Contents

| File | Purpose |
|------|---------|
| `tutorial.qmd` | Self-contained Quarto notebook — prose, code, output, and figures inline. The didactic, render-and-read version of the tutorial. |
| `analysis.R` | Canonical companion script — equivalent logic, runnable directly with `Rscript analysis.R`. Useful if you prefer plain-R execution over rendering. |
| `_quarto.yml` | Minimal Quarto project marker so Positron / RStudio open this folder as a recognised Quarto project (no prompt for a project directory). |
| `README.md` | This file. |

## How to render the tutorial

1. Open this folder in **Positron** or **RStudio**.
2. Open `tutorial.qmd` and click **Render** (or run
   `quarto render tutorial.qmd` from a terminal in this folder).
3. The `setup-packages` chunk pins **exact versions** of every
   top-level R package via `pak::pkg_install("pkg@x.y.z")` and
   installs them on first run (subsequent renders reuse the
   cached versions).
4. The rendered output is `tutorial.html` plus a `tutorial_files/`
   directory of figures. Both are regenerated each time you render.

## How to run the canonical script directly

```bash
Rscript analysis.R 2>&1 | tee execution_log.txt
```

The script downloads the Callaway-Sant'Anna minimum-wage county panel
(`mw_data_ch2.RData`, 2001–2007) from the GitHub raw URL of the
published post (with a local-file fallback if you place the dataset
next to the script).

## Requirements

- **Quarto** ≥ 1.4
- **R** ≥ 4.5
- ~150 MB of CRAN packages on first install (cached after that)

## References

- **Published post:** <https://carlos-mendez.org/post/r_did/>
- **Source repo:** <https://github.com/cmg777/starter-academic-v501>
- **Methodology:** Callaway, B. & Sant'Anna, P. H. C. (2021). Difference-in-Differences with Multiple Time Periods. *Journal of Econometrics*, 225(2), 200–230.
- **Data source:** County-level minimum-wage panel (2001–2007) from Callaway & Sant'Anna's `did` chapter materials.
