# r_sc_bayes_spatial — Quarto project

Executable companion to the blog post:

> **Bayesian Spatial Synthetic Control: California's Proposition 99 in R**
> <https://carlos-mendez.org/post/r_sc_bayes_spatial/>

## Contents

| File | Purpose |
|------|---------|
| `tutorial.qmd` | Self-contained Quarto notebook — prose, code, output, and figures inline. The didactic, render-and-read version of the tutorial. |
| `analysis.R` | Canonical companion script — equivalent logic, runnable directly with `Rscript analysis.R`. Useful if you prefer plain-R execution over rendering. |
| `_quarto.yml` | Minimal Quarto project marker so Positron / RStudio open this folder as a recognised Quarto project (no prompt for a project directory). |
| `README.md` | This file. |

## How to render the tutorial

1. Open this folder in **Positron** or **RStudio**.
2. Open `tutorial.qmd` and click **Render** (or run
   `quarto render tutorial.qmd` from a terminal in this folder).
3. The `setup-packages` chunk pins **exact versions** of every
   top-level R package via `pak::pkg_install("pkg@x.y.z")` and
   installs them on first run (subsequent renders reuse the
   cached versions).
4. The rendered output is `tutorial.html` plus a `tutorial_files/`
   directory of figures. Both are regenerated each time you render.

## How to run the canonical script directly

```bash
Rscript analysis.R 2>&1 | tee execution_log.txt
```

The script uses the California tobacco panel (`california_smoking.rda`,
39 US states, 1970–2000) bundled with the relevant R packages — no
external download required.

## Requirements

- **Quarto** ≥ 1.4
- **R** ≥ 4.5
- ~150 MB of CRAN packages on first install (cached after that)

## References

- **Published post:** <https://carlos-mendez.org/post/r_sc_bayes_spatial/>
- **Source repo:** <https://github.com/cmg777/starter-academic-v501>
- **Methodology:** Sakaguchi, S. & Tagawa, H. (2026). Identification and Bayesian Inference for Synthetic Control Methods with Spillover Effects. *The Econometrics Journal*.
- **Data source:** Abadie, A., Diamond, A. & Hainmueller, J. (2010). Synthetic Control Methods for Comparative Case Studies. *JASA*, 105(490), 493–505.
