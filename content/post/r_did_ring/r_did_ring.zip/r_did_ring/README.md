# r_did_ring — Quarto project

Executable companion to the blog post:

> **Difference-in-Differences with Geocoded Microdata:
> When Distance Defines Treatment**
> <https://carlos-mendez.org/post/r_did_ring/>

## Contents

| File | Purpose |
|------|---------|
| `tutorial.qmd` | Self-contained Quarto notebook — prose, code, output, and figures inline. The didactic, render-and-read version of the tutorial. |
| `analysis.R` | Canonical companion script — equivalent logic, runnable directly with `Rscript analysis.R`. Useful if you prefer plain-R execution over rendering. |
| `_quarto.yml` | Minimal Quarto project marker so Positron / RStudio open this folder as a recognised Quarto project (no prompt for a project directory). |
| `README.md` | This file. |

## How to render the tutorial

1. Open this folder in **Positron** or **RStudio**.
2. Open `tutorial.qmd` and click **Render** (or run
   `quarto render tutorial.qmd` from a terminal in this folder).
3. The `setup-packages` chunk pins **exact versions** of all 13 R
   packages via `pak::pkg_install("pkg@x.y.z")` and installs them on
   first run (subsequent renders reuse the cached versions).
4. The rendered output is `tutorial.html` plus a `tutorial_files/`
   directory of figures. Both are regenerated each time you render.

## How to run the canonical script directly

```bash
Rscript analysis.R 2>&1 | tee execution_log.txt
```

The script downloads the Linden-Rockoff data from the GitHub raw URL
of the published post (with a local-file fallback if `linden_rockoff.dta`
is sitting next to the script).

## Requirements

- **Quarto** ≥ 1.4
- **R** ≥ 4.5 (tested on 4.5.2)
- ~150 MB of CRAN packages on first install (cached after that)

## Notes

- `tutorial.qmd` is fully self-contained: it inlines the helper
  functions (`parametric_ring_panel`, `nonparametric_ring_cs`) and
  does **not** `source("analysis.R")`. The two entry points are
  parallel, not chained.
- The published post pins the same package versions for
  bit-reproducibility — re-rendering on any machine should produce
  the same numbers as the post.

## References

- **Published post:** <https://carlos-mendez.org/post/r_did_ring/>
- **Source repo:** <https://github.com/cmg777/starter-academic-v501>
- **Methodology:** Butts, Kyle (2023). "JUE Insight:
  Difference-in-Differences with Geocoded Microdata." *Journal of
  Urban Economics* 133, 103493.
  <https://doi.org/10.1016/j.jue.2022.103493>
- **Data source:** Linden, Leigh, and Jonah E. Rockoff (2008).
  "Estimates of the Impact of Crime Risk on Property Values from
  Megan's Laws." *American Economic Review* 98(3), 1103–1127.
