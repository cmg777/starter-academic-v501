# Spatial Inequality and the Kuznets Curve — Quarto project

Synthetic R replication of **Lessmann (2014)**, "Spatial inequality and development —
Is there an inverted-U relationship?" (*Journal of Development Economics* 106, 35–51).

## Render
```bash
quarto render tutorial.qmd
```
Open `tutorial.html` in a browser.

## Requirements
R ≥ 4.4 and Quarto ≥ 1.4. The setup chunk installs the needed packages via `pacman`:
`dplyr, tidyr, ggplot2, scales, fixest, sandwich, lmtest, splines, np, modelsummary`.

## Files
- `tutorial.qmd` — the runnable notebook (DGP → WCV → cross-section OLS → fixest TWFE →
  turning points → Robinson semiparametric → sectoral channel).
- `analysis.R` — the full canonical script (all figures, tables and CSV exports).
- `_quarto.yml` — minimal project config.

There is no real data: regional GDP is simulated and the WCV is computed from it, with the
data-generating process calibrated to reproduce the paper's published estimates.
