# r_double_lasso — Quarto project

Executable companion to the blog post:

> **Double LASSO for Causal Inference: Does Abortion Reduce Crime?**
> <https://carlos-mendez.org/post/r_double_lasso/>

## Contents

| File | Purpose |
|------|---------|
| `tutorial.qmd` | Self-contained Quarto notebook — prose, code, output, and figures inline. The didactic, render-and-read version of the tutorial. |
| `analysis.R` | Canonical companion script — equivalent logic, runnable directly with `Rscript analysis.R`. Useful if you prefer plain-R execution over rendering. |
| `_quarto.yml` | Minimal Quarto project marker so Positron / RStudio open this folder as a recognised Quarto project (no prompt for a project directory). |
| `README.md` | This file. |

## How to render the tutorial

1. Open this folder in **Positron** or **RStudio**.
2. Open `tutorial.qmd` and click **Render** (or run
   `quarto render tutorial.qmd` from a terminal in this folder).
3. The `setup-packages` chunk installs the 10 required R packages
   (`glmnet`, `hdm`, `sandwich`, `lmtest`, `ggplot2`, `dplyr`,
   `tidyr`, `scales`, `patchwork`, `MASS`) on first run, then reuses
   them. The exact versions used when the post was published
   (2026-05-21) are listed as comments in the setup chunk for
   bit-reproducible installs.
4. The rendered output is `tutorial.html` plus a `tutorial_files/`
   directory of figures. Both are regenerated each time you render.

## How to run the canonical script directly

```bash
Rscript analysis.R 2>&1 | tee execution_log.txt
```

The script downloads the six Donohue–Levitt 48-state crime panel
CSVs from the GitHub raw URL of the published post — no Matlab
files needed locally.

## Requirements

- **Quarto** ≥ 1.4
- **R** ≥ 4.5 (tested on 4.5.2)
- ~150 MB of CRAN packages on first install (cached after that)

## References

- **Published post:** <https://carlos-mendez.org/post/r_double_lasso/>
- **Source repo:** <https://github.com/cmg777/starter-academic-v501>
- **Methodology:** Fitzgerald, Lattimore, Robinson & Zhu (2026), "Double LASSO: Replication and Practical Insights," *Journal of Applied Econometrics*, forthcoming. DOI: <https://doi.org/10.15456/jae.2025335.0258270663>
- **Data source:** Donohue & Levitt (2001), "The Impact of Legalized Abortion on Crime," *Quarterly Journal of Economics* 116(2): 379-420. DOI: <https://doi.org/10.1162/00335530151144050>
